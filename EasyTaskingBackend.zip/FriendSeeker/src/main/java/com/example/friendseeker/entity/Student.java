package com.example.friendseeker.entity;

import javax.persistence.*;

import com.example.friendseeker.request.StudentRequest;
import com.example.friendseeker.request.TaskRequest;
import com.example.friendseeker.response.StudentResponse;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;
import java.util.stream.Collectors;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "students")
public class Student {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @Column(name="first_name", nullable = false)
    private String firstName;
    @Column(name = "last_name", nullable = false)
    private String lastName;
    @Column(name = "email", nullable = false)
    private String email;


    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name= "task_id")
    private List<Task> tasks;

    public Student(StudentRequest studentRequest) {
        firstName = studentRequest.getFirstName();
        lastName = studentRequest.getLastName();
        email = studentRequest.getEmail();
        tasks = studentRequest.getTasks().stream().map(Task::new).collect(Collectors.toList());
    }
}
