package com.example.friendseeker.service;

import com.example.friendseeker.entity.Task;
import com.example.friendseeker.entity.Student;
import com.example.friendseeker.exception.ResourceNotFoundException;
import com.example.friendseeker.repository.TaskRepository;
import com.example.friendseeker.repository.StudentRepository;
import com.example.friendseeker.request.TaskRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TaskService {
    @Autowired
    private TaskRepository taskRepository;

    @Autowired
    private StudentRepository studentRepository;

    public Task getTask(long taskId){
        Task task = taskRepository.findById(taskId).orElseThrow(()->new ResourceNotFoundException("task id not found"));
        return task;
    }

    public List<Task> getAllTasks(){
        List<Task> taskList = taskRepository.findAll();
        return taskList;
    }

    public Task addTask(TaskRequest taskRequest){

        Task task = new Task(taskRequest);
        taskRepository.save(task);
        return task;
    }

    public Task updateTask(long taskId, TaskRequest taskRequest){
        taskRepository.findById(taskId).orElseThrow(()->new ResourceNotFoundException("task id is not found"));

        Task taskToBeUpdated = new Task(taskRequest);
        taskToBeUpdated.setId(taskId);
        return taskRepository.save(taskToBeUpdated);
    }

    public void deleteTask(long taskId){
        if(taskRepository.existsById(taskId)){
            taskRepository.deleteById(taskId);
        }
        else{
            throw new ResourceNotFoundException("task id not found");
        }
    }

/*
    public void addMember(long groupId, long studentId) {
        Task group = groupRepository.findById(groupId)
                .orElseThrow(() -> new ResourceNotFoundException("Task with id " + groupId + " not found."));
        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new ResourceNotFoundException("Student with id " + studentId + " not found."));
        group.getMembers().add(student);
        groupRepository.save(group);
    }


    public void removeMember(long groupId, long studentId) {
        Optional<Task> group = groupRepository.findById(groupId);
        if (!group.isPresent()) {
            throw new ResourceNotFoundException("Task with id " + groupId + " not found.");
        }
        Task g = group.get();
        Optional<Student> student = studentRepository.findById(studentId);
        if (!student.isPresent()) {
            throw new ResourceNotFoundException("Student with id " + studentId + " not found.");
        }
        g.getMembers().remove(student.get());
        groupRepository.save(g);
    }



    public List<Student> getGroupMembers(long groupId) {
        Task group = groupRepository.findById(groupId)
                .orElseThrow(() -> new ResourceNotFoundException("Task with id " + groupId + " not found."));
        return group.getMembers();
    }
*/
}
