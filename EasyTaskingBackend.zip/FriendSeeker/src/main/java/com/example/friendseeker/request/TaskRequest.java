package com.example.friendseeker.request;

import com.example.friendseeker.entity.Student;
import com.example.friendseeker.entity.Task;
import lombok.*;

import javax.validation.constraints.NotBlank;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TaskRequest {
    @NotBlank
    private String taskName;
    @NotBlank
    private String taskDescription;

    @NotBlank
    private String taskColor;

    private StudentRequest student;


    public TaskRequest(Task task) {
        this.taskName = task.getName();
        this.taskDescription = task.getDescription();
        this.taskColor = task.getTaskColor();
        this.student = new StudentRequest(task.getStudent());
    }

}
