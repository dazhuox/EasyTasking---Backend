package com.example.friendseeker.response;

import com.example.friendseeker.entity.Student;
import com.example.friendseeker.entity.Task;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class StudentResponse {
    private long id;

    private String fullName;

    private String email;

    private List<Task> tasks;


    public StudentResponse(Student student){
        id = student.getId();
        fullName = student.getFirstName() + " " + student.getLastName();
        email = student.getEmail();
        tasks = student.getTasks();
    }
}
