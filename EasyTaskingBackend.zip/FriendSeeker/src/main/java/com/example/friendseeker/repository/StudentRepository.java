package com.example.friendseeker.repository;

import com.example.friendseeker.entity.Student;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface StudentRepository extends CrudRepository<Student, Long> {
    List<Student> findAllByFirstNameIgnoreCase(String firstName);

    List<Student> findAll();
}
