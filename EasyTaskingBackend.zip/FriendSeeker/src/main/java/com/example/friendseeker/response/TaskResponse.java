package com.example.friendseeker.response;

import com.example.friendseeker.entity.Task;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TaskResponse {
    private long id;
    private String name;
    private String description;
    private String taskColor;
    private StudentResponse student;

    public TaskResponse(Task task){
        id = task.getId();
        name = task.getName();
        description = task.getDescription();
        taskColor = task.getTaskColor();
        student = new StudentResponse(task.getStudent());
    }
}
