package com.example.friendseeker.repository;

import com.example.friendseeker.entity.Task;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;

@Repository
public interface TaskRepository extends CrudRepository<Task, Long> {

    List<Task> findALlByStudentId(long student_id);

    @Transactional
    void deleteAllByStudentId(long student_id);

    List<Task> findAll();

}
