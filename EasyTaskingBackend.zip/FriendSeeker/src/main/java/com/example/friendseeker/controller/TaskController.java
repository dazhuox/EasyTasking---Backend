package com.example.friendseeker.controller;

import com.example.friendseeker.entity.Student;
import com.example.friendseeker.entity.Task;
import com.example.friendseeker.request.StudentRequest;
import com.example.friendseeker.request.TaskRequest;
import com.example.friendseeker.response.StudentResponse;
import com.example.friendseeker.response.TaskResponse;
import com.example.friendseeker.service.StudentService;
import com.example.friendseeker.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@CrossOrigin("*")
@RequestMapping("/api/tasks")
public class TaskController {
    @Autowired
    TaskService taskService;

    @Autowired
    StudentService studentService;


    @GetMapping("/{taskId}")
    public TaskResponse getTask(@PathVariable long taskId){
        Task task = taskService.getTask(taskId);
        TaskResponse taskResponse = new TaskResponse(task);
        return taskResponse;
    }

    @GetMapping()
    public List<TaskResponse> getAllTask(){
        List<Task> tasks = taskService.getAllTasks();
        return tasks.stream()
                .map(TaskResponse::new)
                .collect(Collectors.toList());
    }

    @PostMapping()
    @ResponseStatus(HttpStatus.CREATED)
    public TaskResponse addTask(@Valid @RequestBody TaskRequest taskRequest){
        Student student = studentService.getStudentById(taskRequest.getStudent().getId());
        taskRequest.setStudent(new StudentRequest(student));
        Task task = taskService.addTask(taskRequest);

        return new TaskResponse(task);
    }

    @PutMapping("/{taskId}")
    public TaskResponse updateTask(@PathVariable long taskId, @Valid @RequestBody TaskRequest taskRequest){
        System.out.println(taskRequest.getTaskDescription());
        Task task = taskService.updateTask(taskId, taskRequest);
        return new TaskResponse(task);
    }

    @DeleteMapping("/{taskId}")
    public void deleteTask(@PathVariable long taskId){
        taskService.deleteTask(taskId);
    }
}
