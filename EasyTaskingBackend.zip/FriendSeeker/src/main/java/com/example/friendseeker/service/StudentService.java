package com.example.friendseeker.service;

import com.example.friendseeker.entity.Task;
import com.example.friendseeker.entity.Student;
import com.example.friendseeker.exception.ResourceNotFoundException;
import com.example.friendseeker.repository.TaskRepository;
import com.example.friendseeker.repository.StudentRepository;
import com.example.friendseeker.request.TaskRequest;
import com.example.friendseeker.request.StudentRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentService {
    @Autowired
    StudentRepository studentRepository;
    @Autowired
    TaskRepository taskRepository;

    public Student getStudentById(long studentId){
        Student student = studentRepository.findById(studentId).orElseThrow(()-> new RuntimeException(("student id not found")));

        return student;
    }

    public List<Student> getAllStudents(){
        List<Student> studentList = studentRepository.findAll();
        return studentList;
    }

    public Student addStudent(StudentRequest studentRequest)
    {
        Student student = new Student(studentRequest);

        return studentRepository.save(student);
    }

    public Student updateStudent(long studentId, StudentRequest studentRequest)
    {
        studentRepository.findById(studentId)
                .orElseThrow(()->new ResourceNotFoundException("student id is not found"));

        Student studentToBeUpdated = new Student(studentRequest);
        studentToBeUpdated.setId(studentId);

        return studentRepository.save(studentToBeUpdated);
    }

    public void deleteStudent(long studentId){
        if(studentRepository.existsById(studentId)){
            studentRepository.deleteById(studentId);
        }
        else{
            throw new ResourceNotFoundException("student id not found");
        }
    }
}
