package com.example.friendseeker.controller;

import com.example.friendseeker.entity.Student;
import com.example.friendseeker.entity.Task;
import com.example.friendseeker.request.TaskRequest;
import com.example.friendseeker.request.StudentRequest;
import com.example.friendseeker.response.TaskResponse;
import com.example.friendseeker.response.StudentResponse;
import com.example.friendseeker.service.TaskService;
import com.example.friendseeker.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@CrossOrigin("*")
@RequestMapping("/api/students")
public class StudentController {

    @Autowired
    StudentService studentService;

    @GetMapping("/{studentId}")
    public StudentResponse getStudent(@PathVariable long studentId){
        Student student = studentService.getStudentById(studentId);
        StudentResponse studentResponse = new StudentResponse(student);
        return studentResponse;
    }

    @GetMapping()
    public List<StudentResponse> getAllStudent(){
        List<Student> students = studentService.getAllStudents();
        return students.stream()
                .map(StudentResponse::new)
                .collect(Collectors.toList());
    }

    @PostMapping()
    @ResponseStatus(HttpStatus.CREATED)
    public StudentResponse addStudent(@Valid @RequestBody StudentRequest studentRequest){
        Student student = studentService.addStudent(studentRequest);

        return new StudentResponse(student);
    }

    @PutMapping("/{studentId}")
    public StudentResponse updateStudent(@PathVariable long studentId, @Valid @RequestBody StudentRequest studentRequest){
        Student student = studentService.updateStudent(studentId, studentRequest);
        return new StudentResponse(student);
    }

    @DeleteMapping("/{studentId}")
    public void deleteStudent(@PathVariable long studentId){
        studentService.deleteStudent(studentId);
    }

}

