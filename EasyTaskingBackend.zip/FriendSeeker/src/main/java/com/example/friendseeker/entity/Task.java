package com.example.friendseeker.entity;

import com.example.friendseeker.request.TaskRequest;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "tasks")
public class Task {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String description;

    @Column(nullable = false)
    private String taskColor;

    @ManyToOne(optional = false, cascade = CascadeType.DETACH)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JoinColumn(name= "student_id")

    private Student student;

    public Task(TaskRequest taskRequest){
        name = taskRequest.getTaskName();
        description = taskRequest.getTaskDescription();
        taskColor = taskRequest.getTaskColor();
        student = new Student (taskRequest.getStudent());
    }

}
