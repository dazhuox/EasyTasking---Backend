
insert into Students (FIRST_NAME, LAST_NAME, EMAIL) VALUES ('DaZhuo', 'Xie', 'dazhuoxie1024@gmail.com');
insert into Students (FIRST_NAME, LAST_NAME, EMAIL) VALUES ('Tawfiq', 'Jawhar', 'tawfiq123jawhar@gmail.com');

insert into Tasks (NAME, DESCRIPTION, TASK_COLOR, STUDENT_ID) VALUES ('EAT', 'PUT FOOD IN MOUTH', '#72AEF6', 1);
insert into Tasks (NAME, DESCRIPTION, TASK_COLOR, STUDENT_ID) VALUES ('Task 2', 'Here is a task with an extremely lot of information. Here is a task with an extremely lot of information. Here is a task with an extremely lot of information. Here is a task with an extremely lot of information.', '#72AEF6', 1);
insert into Tasks (NAME, DESCRIPTION, TASK_COLOR, STUDENT_ID) VALUES ('Task 3', 'Sleep more', '#72AEF6', 1);
insert into Tasks (NAME, DESCRIPTION, TASK_COLOR, STUDENT_ID) VALUES ('Task 4', 'Drink Water', '#72AEF6', 1);
insert into Tasks (NAME, DESCRIPTION, TASK_COLOR, STUDENT_ID) VALUES ('Task 5', 'Finish project', '#72AEF6', 1);


