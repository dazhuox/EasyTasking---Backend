import React from 'react';
import ReactDOM from 'react-dom';

const App = () => {
    return <div>Hello World!</div>;
};

ReactDOM.render(<App />, document.getElementById('root'));
