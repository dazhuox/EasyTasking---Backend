package com.example.friendseeker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FriendSeekerApplicationTests {

    @Test
    void contextLoads() {
    }

}
